EXPLICIT_DESC = """[GRAMMAR RULES]
1) Word Order: Subject-Verb-Object (SVO)
   - The subject comes first
   - The verb comes second  
   - The object comes third
   - Adverbs can appear optionally at the end
"""

EXPLICIT_DEMO =  """Examples:
   ✓ Correct: "The dog eats the bone."
   ✓ Correct: "They will hunt birds sometimes."
   ✗ Incorrect: "Eats the dog the bone." (VSO order)
   ✗ Incorrect: "The bone the dog eats." (OSV order)
"""
EXPLICIT_FULL = f"{EXPLICIT_DESC}\n2) Examples:\n{EXPLICIT_DEMO}"

IMPLICIT_EXAMPLES = """[EXAMPLES]
✓ The dog eats the bone.
✓ They will hunt birds sometimes.
✓ Each zebra has a unique pattern.
✗ Eats the dog the bone.
✗ The bone the dog eats.
"""

def build_prompt(ex: dict, condition: str) -> str:
    sent = ex.get("text", "")
    condition = (condition or "").lower()

    if condition == "explicit":
        rule_section = f"{EXPLICIT_FULL}\n\n"
    elif condition == "explicit_a":
        rule_section = f"{EXPLICIT_DESC}\n\n"
    elif condition == "explicit_b":
        rule_section = f"{EXPLICIT_DEMO}\n\n"
    else:
        rule_section = f"{IMPLICIT_EXAMPLES}\n\n"
    return f"{rule_section}Sentence: {sent}"
